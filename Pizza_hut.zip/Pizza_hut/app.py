from flask import Flask, render_template
app = Flask(__name__)


pizza_menu = [
    {"name": "Моцарела", "description": "Піца з моцарелою", "price": 270},
    {"name": "Ветчина", "description": "Піца з ветчиною", "price": 350},
    {"name": "Солодкий перець", "description": "Піца з солодким перцем", "price": 400},
]

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/menu')
def menu():
    return render_template('menu.html', pizza_menu=pizza_menu)

if __name__ == '__main__':
    app.run(debug=True)